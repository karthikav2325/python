s1={1,2,3,6,5,5}
s2={'a','b','c'}
s3=(s1).union(s2)
print(s3)