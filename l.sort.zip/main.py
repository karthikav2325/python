t=(1,2,4,5,'name')
print(t)