name='YUVAshree'
a=name.swapcase()
print(a)