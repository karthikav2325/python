l=[0.5,5,True,'karthi']
print(l[0:2])
