name='KARTHIKA'
a=name.lower()
print(a)