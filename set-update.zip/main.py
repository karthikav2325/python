s1={1,2,3,6,5,5}
s2={'a','b','c'}
s1.update(s2)
print(s1)