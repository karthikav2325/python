l=[0.5,4,False,"karthi"]
l.insert(2,True)
print(l)