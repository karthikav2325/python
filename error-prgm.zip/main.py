name='karthika'
name[1]='u'
print(name)