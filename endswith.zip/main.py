name='karthika'
a=name.endswith('a')
print(a)
