name='KARTHIKA'
a=name.islower()
print(a)