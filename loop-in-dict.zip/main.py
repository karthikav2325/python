d={"name":"xyz","age":20,"address":"abc","marks":0.5}
for i in d:
    print(d[i])
print(d["name"])