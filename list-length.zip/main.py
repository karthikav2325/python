l=[0.5,5,True,'karthi']
print(len(l))