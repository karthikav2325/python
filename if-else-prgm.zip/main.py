a=5
if a>0:
    if a<10:
        print(a)
    else:
        print("hi")
else:
    print("hello")