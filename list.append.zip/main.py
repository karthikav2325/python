l=[0.5,5,True,'karthi']
a=l.append(45)
print(l)