name='karthika'
print(name[0:8:2])