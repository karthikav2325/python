a=3+4j
b=6+8j
c=a+b 
print(c)
