a=19
if a<0:
    print("It is negative")
elif a>0:
    print("It is positive")
else:
    print("The number is zero")
