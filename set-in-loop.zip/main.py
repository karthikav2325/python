sd={1,2,4,3,0.6}
for i in sd:
    print(i)