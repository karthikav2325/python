l=[0.5,5,'hi','ji']
l.insert(2,'fi')
l.pop(3)
print(l)