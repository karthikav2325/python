name='KARTHIKA'
a=name.startswith('K')
print(a)