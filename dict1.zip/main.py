d={2,3,4}
d={"abc":2,"xyz":3,"cde":4,"pqr":5,"stu":4}
print(d["xyz"])