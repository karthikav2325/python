for i in range(2,10,2):
    print(i,end=' ')