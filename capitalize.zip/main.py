name='KARTHIKA'
a=name.capitalize()
print(a)