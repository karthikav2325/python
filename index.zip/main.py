name='karthika'
a=name.index('i')
print(a)